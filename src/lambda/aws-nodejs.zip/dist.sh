rm pdftk-example.zip
zip pdftk-example.zip pdftk.js bin/*
